from flask import Flask, request, jsonify, render_template
from datetime import datetime
import joblib
import random
import threading
import time
import requests

app = Flask(__name__)

model = joblib.load("model.pkl")

data_store = []

demo_running = True
last_real_data_time = None


def predict_status(g1, g2, dist):
    pred = model.predict([[g1, g2, dist]])[0]
    proba = model.predict_proba([[g1, g2, dist]])
    confidence = max(proba[0]) * 100
    return pred, round(confidence, 2)


def get_location():
    try:
        res = requests.get("http://ip-api.com/json/")
        data = res.json()
        return data['lat'], data['lon']
    except:
        return 19.0760, 72.8777


def generate_demo_data():
    global demo_running

    while True:
        if demo_running:

            level = random.choice(["SAFE","SAFE","WARNING","SAFE","WARNING","DANGER"])

            if level == "SAFE":
                gas1 = random.randint(100,180)
                gas2 = random.randint(120,200)
                distance = random.randint(40,60)

            elif level == "WARNING":
                gas1 = random.randint(180,260)
                gas2 = random.randint(200,300)
                distance = random.randint(25,40)

            else:
                gas1 = random.randint(300,400)
                gas2 = random.randint(350,420)
                distance = random.randint(10,20)

            status, confidence = predict_status(gas1, gas2, distance)
            lat, lon = get_location()

            record = {
                "time": datetime.now().strftime("%H:%M:%S"),
                "gas1": gas1,
                "gas2": gas2,
                "distance": distance,
                "status": status,
                "confidence": confidence,
                "lat": lat,
                "lon": lon
            }

            data_store.append(record)

            if len(data_store) > 100:
                data_store.pop(0)

        time.sleep(3)


@app.route('/')
def index():
    return render_template("dashboard.html")


@app.route('/data', methods=['POST'])
def receive_data():
    global demo_running, last_real_data_time

    raw = request.form.get('data')

    try:
        gas1, gas2, distance = map(float, raw.split(','))
    except:
        return "Invalid Data", 400

    demo_running = False
    last_real_data_time = time.time()

    lat, lon = get_location()
    status, confidence = predict_status(gas1, gas2, distance)

    record = {
        "time": datetime.now().strftime("%H:%M:%S"),
        "gas1": gas1,
        "gas2": gas2,
        "distance": distance,
        "status": status,
        "confidence": confidence,
        "lat": lat,
        "lon": lon
    }

    data_store.append(record)

    if len(data_store) > 100:
        data_store.pop(0)

    print("📥 REAL:", record)

    return jsonify({"message": "OK"})


@app.route('/api/data')
def get_data():
    return jsonify(data_store)


def monitor_data():
    global demo_running, last_real_data_time

    while True:
        if last_real_data_time:
            if time.time() - last_real_data_time > 10:
                demo_running = True
        time.sleep(5)


if __name__ == '__main__':
    threading.Thread(target=generate_demo_data, daemon=True).start()
    threading.Thread(target=monitor_data, daemon=True).start()
    app.run(debug=True)