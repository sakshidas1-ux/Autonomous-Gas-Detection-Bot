import pandas as pd
from sklearn.model_selection import train_test_split
from sklearn.ensemble import RandomForestClassifier
import joblib

# Load dataset
data = pd.read_csv("data.csv")

# 🔥 CLEAN DATA
data = data.dropna()  # remove empty rows
data['label'] = data['label'].str.strip()  # remove spaces

# Convert to correct types
data['gas1'] = data['gas1'].astype(float)
data['gas2'] = data['gas2'].astype(float)
data['distance'] = data['distance'].astype(float)

# Features & labels
X = data[['gas1', 'gas2', 'distance']]
y = data['label']

# Split
X_train, X_test, y_train, y_test = train_test_split(X, y, test_size=0.2)

# Train
model = RandomForestClassifier()
model.fit(X_train, y_train)

# Accuracy
accuracy = model.score(X_test, y_test)
print("Model Accuracy:", accuracy)

# Save model
joblib.dump(model, "model.pkl")
print("Model saved as model.pkl")